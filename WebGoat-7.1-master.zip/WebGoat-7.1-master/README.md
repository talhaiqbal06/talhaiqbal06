# WebGoat-7.1
Legacy version of Web Goat
